from django.db import models

# Create your models here.
class Provinsi(models.Model):
    id = id = models.BigIntegerField(primary_key=True)
    name = models.CharField(max_length=255)
    alt_name = models.CharField(max_length=255, default='')
    latitude = models.FloatField(default=0.0)
    longitude = models.FloatField(default=0.0)

    class Meta:
        db_table = 'provinces'  # Menyesuaikan nama tabel asli di database

    def __str__(self):
        return self.name
    
class Kabkota(models.Model):
    id = models.BigIntegerField(primary_key=True)
    province = models.ForeignKey(
        Provinsi, 
        on_delete=models.CASCADE, 
        db_column='province_id',  # Memastikan nama kolom di DB tetap 'province_id'
        related_name='kabkota_set'
    )
    name = models.CharField(max_length=255)
    alt_name = models.CharField(max_length=255, default='')
    latitude = models.FloatField(default=0.0)
    longitude = models.FloatField(default=0.0)

    class Meta:
        db_table = 'regencies'  # Menyesuaikan dengan nama tabel di database

    def __str__(self):
        return self.name
    
class Kecamatan(models.Model):
    id = models.BigIntegerField(primary_key=True)
    regency = models.ForeignKey(
        Kabkota, 
        on_delete=models.CASCADE, 
        db_column='regency_id',  # Memastikan nama kolom di DB tetap 'regency_id'
        related_name='kecamatan_set'
    )
    name = models.CharField(max_length=255)
    alt_name = models.CharField(max_length=255, default='')
    latitude = models.FloatField(default=0.0)
    longitude = models.FloatField(default=0.0)

    class Meta:
        db_table = 'districts'  # Menyesuaikan dengan nama tabel asli di database

    def __str__(self):
        return self.name
    
    # wilayah/models.py

class NamaData(models.Model):
    nama= models.CharField(max_length=255)
    class Meta:
        db_table = 'namadata'

class Datprof(models.Model):
    provinsi = models.ForeignKey(Provinsi, on_delete=models.CASCADE, db_column='provinsi_id', related_name='datprof_provinsi')
    namadata = models.ForeignKey(NamaData, on_delete=models.CASCADE, db_column='namadata_id', related_name='datprof_namadata')
    tahun = models.IntegerField()
    jumlah = models.FloatField()

    class Meta:
        db_table = 'data_provinces'
        