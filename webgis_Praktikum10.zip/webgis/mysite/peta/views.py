from django.shortcuts import render
from .models import Provinsi, NamaData, Datprof
import json

def index(request):
    return render(request, 'index.html')

def peta(request):
    # 1. Ambil semua judul statistik untuk isi filter dropdown
    all_data_names = NamaData.objects.all()
    
    # 2. Ambil data SEMUA provinsi di Indonesia untuk tabel di bawah peta
    semua_provinsi = Provinsi.objects.all().order_by('id')
    
    # 3. Tangkap filter yang diklik oleh user di halaman web peta
    selected_data_id = request.GET.get('data_id')
    selected_year = request.GET.get('tahun')
    
    stat_data = []
    sub_judul_kecil = ""
    
    # 4. Jika user sudah memilih filter, ambil data angkanya dari database
    if selected_data_id and selected_year:
        data_name_obj = NamaData.objects.get(id=selected_data_id)
        sub_judul_kecil = f"({data_name_obj.nama} Tahun {selected_year})"
        
        records = Datprof.objects.filter(namadata_id=selected_data_id, tahun=selected_year)
        for r in records:
            stat_data.append({
                'prov_name': r.provinsi.name,
                'latitude': r.provinsi.latitude,
                'longitude': r.provinsi.longitude,
                'jumlah': r.jumlah
            })
            
    context = {
        'all_data_names': all_data_names,
        'semua_provinsi': semua_provinsi, # Ini dikirim biar tabel di bawah peta bisa keisi otomatis
        'stat_data': json.dumps(stat_data),
        'sub_judul_kecil': sub_judul_kecil
    }
    return render(request, 'peta.html', context)